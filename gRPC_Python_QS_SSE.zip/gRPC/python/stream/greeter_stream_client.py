import grpc
import hellostreamingworld_pb2
import hellostreamingworld_pb2_grpc

if __name__ == '__main__':
  channel = grpc.insecure_channel('localhost:50052')
  stub = hellostreamingworld_pb2_grpc.MultiGreeterStub(channel)
  requests = []
  requests.append(hellostreamingworld_pb2.HelloRequest(name='山田太郎', num_greetings='5'))
  requests.append(hellostreamingworld_pb2.HelloRequest(name='FooBar', num_greetings='5'))
  responses = stub.SayHello(iter(requests))
  for response in responses:
    print("Greeter client received: " + response.message)
  channel.close()
