from concurrent import futures
import grpc
import hellostreamingworld_pb2
import hellostreamingworld_pb2_grpc

class MultiGreeter(hellostreamingworld_pb2_grpc.MultiGreeterServicer):
  def SayHello(self, request_iterator, context):
    for request in request_iterator:
      print("Received request: {}".format(request))
      for greet in range(int(request.num_greetings)):
        yield hellostreamingworld_pb2.HelloReply(message='こんにちは %s! %i' % (request.name, greet))

if __name__ == '__main__':
  server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
  hellostreamingworld_pb2_grpc.add_MultiGreeterServicer_to_server(
                                                      MultiGreeter(), server)
  server.add_insecure_port('[::]:50052')
  server.start()
  try:
    server.wait_for_termination()
  except KeyboardInterrupt:
    server.stop(0)
