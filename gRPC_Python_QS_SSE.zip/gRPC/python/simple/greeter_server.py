from concurrent import futures
import grpc
import helloworld_pb2
import helloworld_pb2_grpc

class Greeter(helloworld_pb2_grpc.GreeterServicer):
  def SayHello(self, request, context):
    #context.set_code(grpc.StatusCode.UNIMPLEMENTED)
    #context.set_details('Method not implemented!')
    #raise NotImplementedError('Method not implemented!')
    print("Received request: {}".format(request))
    return helloworld_pb2.HelloReply(message='こんにちは %s!' % request.name)

if __name__ == '__main__':
  server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
  helloworld_pb2_grpc.add_GreeterServicer_to_server(Greeter(), server)
  server.add_insecure_port('[::]:50051')
  server.start()
  try:
    server.wait_for_termination()
  except KeyboardInterrupt:
    server.stop(0)
