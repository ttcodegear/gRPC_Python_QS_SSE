from concurrent import futures
import grpc
import helloworld_pb2
import helloworld_pb2_grpc

class Greeter(helloworld_pb2_grpc.GreeterServicer):
  def SayHello(self, request, context):
    print("Received request: {}".format(request))
    return helloworld_pb2.HelloReply(message='こんにちは %s!' % request.name)

if __name__ == '__main__':
  server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
  helloworld_pb2_grpc.add_GreeterServicer_to_server(Greeter(), server)
  with open('./server.key', 'rb') as f:
    SERVER_CERT_KEY = f.read()
  with open('./server.crt', 'rb') as f:
    SERVER_CERT = f.read()
  server_credentials = grpc.ssl_server_credentials(((
                                      SERVER_CERT_KEY, SERVER_CERT,),))
  server.add_secure_port('[::]:50051', server_credentials)
  server.start()
  try:
    server.wait_for_termination()
  except KeyboardInterrupt:
    server.stop(0)
